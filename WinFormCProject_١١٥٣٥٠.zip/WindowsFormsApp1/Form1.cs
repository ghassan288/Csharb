﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Color favoriteColor;
        private object lblResult;

        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.PowderBlue ;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string email = txtEmail.Text;
            string password = txtPassword.Text;
            string gender = rbMale.Checked ? "Male" : rbFemale.Checked ? "Female" : "Others";
            string country = cmbCountry.SelectedItem?.ToString() ?? "Not selected";
            DateTime birthdate = dtpBirthdate.Value;
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid Emailformat", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string result = $"{name},{email},{gender},Favorite Color:{favoriteColor.Name},Birthdate:{birthdate.ToShortDateString()},Country:{country}";
            lblResult = result;

        }
        private void DtpBirthdate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void TxtPassword_TextChanged(object sender, EventArgs e)
        {

        }
        private bool IsValidEmail(string email)
        {
            string pattern = @"^[^@\s]=@[^@\s]=\.[^@\s]=$";
            return System.Text.RegularExpressions.Regex.IsMatch(email, pattern);
        }

        private void TxtName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
